<?php 

return array(
	'default'=> __( 'Typography', BASEMENT_SHORTCODES_TEXTDOMAIN )
);