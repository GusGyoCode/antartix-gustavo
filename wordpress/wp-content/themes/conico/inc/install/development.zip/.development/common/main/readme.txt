=== Conico ===
Contributors: Aisconverse team
Requires at least: WordPress 4.7
Tested up to: WordPress 4.7-trunk
Version: @VER@
License: GNU General Public License
License URI: http://www.gnu.org/copyleft/gpl.html
Tags: left-sidebar, right-sidebar, one-column, two-columns, three-columns, four-columns, custom-colors, editor-style, post-formats, sticky-post, theme-options, translation-ready, threaded-comments

== Description ==
Cross Browser, High Quality and Responsive Multipurpose WordPress Theme.
Thank you very much for purchasing our WordPress theme. It is built with the latest HTML5 and CSS3 technologies, but at the same time it is also made compatible with older browser versions.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Upload Conico & Conico Child template.
3. Click on the 'Activate' button to use your new theme right away.
4. Go to guide on how to customize this theme.
5. Navigate to Appearance > Customize or Appearance > Theme Settings in your admin panel and customize to taste.

== Changelog ==

= 1.0 =
* Released: July 21, 2017

Initial release