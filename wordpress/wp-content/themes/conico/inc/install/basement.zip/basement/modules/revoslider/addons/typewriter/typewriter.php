<?php

require_once(REVO_TYPEWRITER_PATH . 'includes/base.class.php');

new Basement_RS_Typewriter_Base();
