var $        = require('gulp-load-plugins')();
var argv     = require('yargs').argv;
var gulp     = require('gulp');
var rimraf   = require('rimraf');
var sequence = require('run-sequence');
var prettier = require('gulp-prettier');
var eslint = require('gulp-eslint');
var replace = require('gulp-string-replace');

// Check for --flag
var isMinify = !!(argv.minify);
var isDev = !!(argv.dev);


// Browsers to target when prefixing CSS
var COMPATIBILITY = ['last 2 versions', 'ie >= 9', '> 1%', 'iOS 7', 'Firefox >= 20', 'Firefox ESR', 'and_chr >= 2.3', 'Opera 12.1'];

// dest Theme variables
var THEME = '../conico';
var THEME_ASSETS = THEME + '/assets';
var THEME_ASSETS_CSS = THEME_ASSETS + '/css';
var THEME_ASSETS_JS = THEME_ASSETS + '/js';
var THEME_ASSETS_JS_VENDOR = THEME_ASSETS_JS + '/vendor';
var THEME_ASSETS_FONTS = THEME_ASSETS + '/fonts';
var THEME_ASSETS_IMAGES = THEME_ASSETS + '/images';

var CHILD_THEME = '../conico-child';

// Theme Version
var VER = '1.0';


var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();

if(dd<10) {
  dd='0'+dd;
}

if(mm<10) {
  mm='0'+mm;
}

var TODAY = dd+'/'+mm+'/'+yyyy;

// Path to Bower components
var PATHS = {
  js_files : [
    'bower_components/html5shiv/dist/html5shiv.js',
    'bower_components/bootstrap-sass/assets/javascripts/bootstrap.js',
    'bower_components/respond/dest/respond.src.js'
  ],
  js_plugins: [
    'js/plugins/after-resize.js',
    'bower_components/jquery-hoverintent/jquery.hoverIntent.js',
    'bower_components/jquery-validation/dist/jquery.validate.js',
    'bower_components/jquery.uniform/src/js/jquery.uniform.js',
    'bower_components/superfish/dist/js/superfish.js'
  ]
};




// Delete the "assets" folder and other files
// This happens every time a build starts
gulp.task('clean', function(done) {
  rimraf('{' + THEME_ASSETS + ','+THEME+'/style.css,'+THEME+'/favicon.ico,'+THEME+'/readme.txt,'+THEME+'/screenshot.png,'+THEME+'/version.txt}', done);
});
gulp.task('clean_child', function(done) {
  rimraf('{'+CHILD_THEME+'/style.css,'+CHILD_THEME+'/screenshot.png}', done);
});

// Minify SVG files
gulp.task('svgmin', function () {
  return gulp.src('svg/**/*')
    .pipe($.svgmin())
    .pipe(gulp.dest('../svg'));
});





gulp.task('bootstrap', function() {

  var minifycss = $.if(!isDev, $.cleanCss({ compatibility: 'ie9' }));
  var beautify = $.if(isDev, $.cssbeautify({ autosemicolon: true }));

  return gulp.src('scss/bootstrap.scss')
    .pipe($.sass().on('error', $.sass.logError))
    .pipe($.autoprefixer({
      browsers: COMPATIBILITY
    }))
    .pipe(beautify)
    .pipe(minifycss)
    .pipe($.rename({ extname: ".min.css" }))
    .pipe(gulp.dest(THEME_ASSETS_CSS))
});


gulp.task('styles', function() {

  var minifycss = $.if(!isDev, $.cleanCss({
    compatibility: 'ie9',
    debug: true,
    rebase: false
  }));
  var beautify = $.if(isDev, $.cssbeautify({ autosemicolon: true }));
  var mapInit = $.if(isDev, $.sourcemaps.init());
  var mapWrite = $.if(isDev, $.sourcemaps.write());


  return gulp.src(['scss/fonts/**/{*.scss, *.sass}','scss/js-composer/**/{*.scss, *.sass}', 'scss/development.scss'])
    .pipe($.sass().on('error', $.sass.logError))
    .pipe($.autoprefixer({
      browsers: COMPATIBILITY
    }))
    .pipe(mapInit)
    .pipe(minifycss)
    .pipe(beautify)
    .pipe($.rename({ extname: ".min.css" }))
    .pipe(mapWrite)
    .pipe(gulp.dest(THEME_ASSETS_CSS))
});


gulp.task('main_styles', function() {
  var path = {
    'scss/style.scss' : THEME,
    'scss/editor-style.scss' : THEME_ASSETS_CSS
  };


  Object.keys(path).map(function(src, index) {

    var minifycss = $.if(isMinify, $.cleanCss({
      compatibility: 'ie9',
      rebase: false
    }));

    var beautify = $.if(!isMinify, $.cssbeautify({ autosemicolon: true }));
    var mapInit = $.if(isDev, $.sourcemaps.init());
    var mapWrite = $.if(isDev, $.sourcemaps.write());

    var value = path[src];
    return gulp.src(src)
      .pipe($.sass().on('error', $.sass.logError))
      .pipe($.autoprefixer({
        browsers: COMPATIBILITY,
        grid : true
      }))
      .pipe(replace('@VER@', VER))
      .pipe(replace('@TODAY@', TODAY))
      .pipe(mapInit)
      .pipe(minifycss)
      .pipe(beautify)
      .pipe(mapWrite)
      .pipe(gulp.dest(value));
  });
});

gulp.task ('child_styles', function () {

  var minifycss = $.if (isMinify, $.cleanCss ({
    compatibility : 'ie9',
    rebase : false
  }));
  var beautify = $.if (!isMinify, $.cssbeautify ({ autosemicolon : true }));
  var mapInit = $.if (isDev, $.sourcemaps.init ());
  var mapWrite = $.if (isDev, $.sourcemaps.write ());

  return gulp.src ('scss/style-child.scss')
    .pipe ($.sass ().on ('error', $.sass.logError))
    .pipe ($.autoprefixer ({
      browsers : COMPATIBILITY,
      grid : true
    }))
    .pipe(replace('@VER@', VER))
    .pipe (mapInit)
    .pipe (minifycss)
    .pipe (beautify)
    .pipe (mapWrite)
    .pipe($.rename({ basename: "style" }))
    .pipe (gulp.dest (CHILD_THEME));
});







// Combine JavaScript into one file
gulp.task('js_plugins', function() {
  var uglify = $.if(!isDev, $.uglify()
    .on('error', function (e) {
      console.log(e);
    }));

  return gulp.src(PATHS.js_plugins)
    .pipe($.concat('plugins.min.js'))
    .pipe(uglify)
    .pipe(gulp.dest(THEME_ASSETS_JS_VENDOR))
});

gulp.task('js_files', function() {
  var uglify = $.if(!isDev, $.uglify()
    .on('error', function (e) {
      console.log(e);
    }));

  return gulp.src(PATHS.js_files)
    .pipe(uglify)
    .pipe($.rename({ extname: ".min.js" }))
    .pipe(gulp.dest(THEME_ASSETS_JS_VENDOR))
});

gulp.task ('js_custom', function () {
  var uglify = $.if(isMinify, $.uglify()
    .on('error', function (e) {
      console.log(e);
    }));
  var eslints = $.if(!isMinify, eslint ({
    fix : true
  }));

  var formats = $.if(!isMinify, eslint.format ('node_modules/eslint-formatter-pretty'));

  return gulp.src ('js/custom.js')
    .pipe(eslints)
    .pipe(uglify)
    .pipe(formats)
    .pipe(gulp.dest (THEME_ASSETS_JS));
});


// Copy all fonts
gulp.task('fonts', function() {
  return gulp.src('fonts/**/*')
    .pipe(gulp.dest(THEME_ASSETS_FONTS));
});


// Copy main/child theme necessary files
gulp.task('common_main_etc', function() {
  return gulp.src(['common/main/**/*', '!common/main/**/{*.txt, *.doc, *.html}'])
    .pipe(gulp.dest(THEME));
});
gulp.task('common_main',['common_main_etc'], function() {
  return gulp.src('common/main/**/{*.txt, *.doc, *.html}')
    .pipe(replace('@VER@', VER))
    .pipe(gulp.dest(THEME));
});
gulp.task('common_child', function() {
  return gulp.src('common/child/**/*')
    .pipe(gulp.dest(CHILD_THEME));
});



// Copy images to the "dist" folder
gulp.task('images', function() {
  var imagemin = $.if(!isDev, $.imagemin({
    progressive: true
  }));

  return gulp.src('images/**/*')
    .pipe(imagemin)
    .pipe(gulp.dest(THEME_ASSETS_IMAGES));
});



// Build the "assets" folder by running all of the above tasks
gulp.task('build', function(done) {
  sequence('clean',['bootstrap', 'main_styles', 'styles', 'js_files', 'js_plugins', 'js_custom', 'fonts', 'images', 'common_main'], done);
});


// Build the styles for child theme
gulp.task('build_child', function(done) {
  sequence('clean_child',['child_styles', 'common_child'], done);
});


gulp.task('full_build', function(done) {
  sequence('build','build_child', done);
});



// Build and Watch the main theme
gulp.task('default', ['build'], function() {
  gulp.watch(['scss/**/{*.scss, *.sass}'], ['bootstrap', 'main_styles', 'styles']);
  gulp.watch(['js/**/*.js'], [ 'js_files', 'js_plugins', 'js_custom']);
  gulp.watch(['fonts/**/*'], [ 'fonts']);
  gulp.watch(['common/main/**/*'], [ 'common_main']);
  gulp.watch(['images/**/*'], ['images']);
});



// Build and Watch the main theme
gulp.task('child', ['build_child'], function() {
  gulp.watch(['scss/style-child.scss'], ['child_styles']);
  gulp.watch(['common/child/**/*'], [ 'common_child']);
});


// Build and Watch the main&child theme
gulp.task('full_dev', ['build', 'build_child'], function() {
  gulp.watch(['scss/**/{*.scss, *.sass}','!scss/**/style-child.scss'], ['bootstrap', 'main_styles', 'styles']);
  gulp.watch(['js/**/*.js'], [ 'js_files', 'js_plugins', 'js_custom']);
  gulp.watch(['fonts/**/*'], [ 'fonts']);
  gulp.watch(['common/main/**/*'], [ 'common_main']);
  gulp.watch(['images/**/*'], ['images']);

  gulp.watch(['scss/style-child.scss'], ['child_styles']);
  gulp.watch(['common/child/**/*'], [ 'common_child']);
});